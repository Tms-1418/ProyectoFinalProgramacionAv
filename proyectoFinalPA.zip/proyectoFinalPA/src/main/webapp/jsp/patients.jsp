<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

    <title>Pacientes</title>

    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">

</head>

<body>

    <div class="container">

        <h1>Gestión de Pacientes</h1>

        <div class="card">

            <h2>Registrar Paciente</h2>

            <form>

                <label for="name">
                    Nombre Completo
                </label>

                <input
                    type="text"
                    id="name"
                    name="name"
                >

                <label for="document">
                    Documento
                </label>

                <input
                    type="text"
                    id="document"
                    name="document"
                >

                <label for="age">
                    Edad
                </label>

                <input
                    type="number"
                    id="age"
                    name="age"
                >

                <label for="phone">
                    Teléfono
                </label>

                <input
                    type="text"
                    id="phone"
                    name="phone"
                >

                <button type="submit">
                    Registrar Paciente
                </button>

            </form>

        </div>

    </div>

</body>

</html>