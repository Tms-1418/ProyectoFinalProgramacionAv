<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

    <title>Dashboard</title>

    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">

</head>

<body>

    <div class="container">

        <h1>Sistema de Triaje Hospitalario</h1>

        <div class="card">

            <h2>Panel Principal</h2>

            <p>Bienvenido al sistema de gestión hospitalaria.</p>

            <div class="menu">

                <a href="patients.jsp">
                    Registrar Pacientes
                </a>

                <a href="triage.jsp">
                    Generar Triaje
                </a>

                <a href="waitingRoom.jsp">
                    Sala de Espera
                </a>

                <a href="doctorPanel.jsp">
                    Panel Médico
                </a>

            </div>

        </div>

    </div>

</body>

</html>