<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

    <title>Login</title>

    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">

</head>

<body>

    <div class="container">

        <div class="card">

            <h1>Sistema de Triaje Hospitalario</h1>

            <h2>Inicio de Sesión</h2>

            <form>

                <label for="username">
                    Usuario
                </label>

                <input 
                    type="text" 
                    id="username"
                    name="username"
                    placeholder="Ingrese su usuario"
                >

                <label for="password">
                    Contraseña
                </label>

                <input 
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Ingrese su contraseña"
                >

                <button type="submit">
                    Ingresar
                </button>

            </form>

        </div>

    </div>

</body>

</html>